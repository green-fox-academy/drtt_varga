# ADC interrupt
- Use the [provided files](files/) as a starting point
- Read the voltage on the PC1 pin using the ADC Conversion Complete interrupt
- In the interrupt handler send the result with `printf()` as a string in Volts
